#!/usr/bin/env bash
# FitSync - one-click launcher for Mac/Linux:  bash run_app_mac_linux.sh
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -q -r requirements.txt
streamlit run app.py
